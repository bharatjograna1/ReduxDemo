/**
 * App Reducers
 */
import { combineReducers } from "redux";
import FetchDBData from "./FetchDBData";

const reducers = combineReducers({
  FetchDBDataRdcr: FetchDBData,
});

export default reducers;