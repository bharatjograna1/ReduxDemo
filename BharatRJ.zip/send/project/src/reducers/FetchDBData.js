/**
 * App Settings Reducers
 */

import {

  //For Fetch DB Data
  FETCH_DB_DATA,
  FETCH_DB_DATA_SUCCESS,
  FETCH_DB_DATA_FAILURE,

} from "../actions";

/**
 * initial app settings
 */
const INIT_STATE = {
  loading: false,
  FetchDBData: []
};

export default (state, action) => {

  if (typeof state === 'undefined') {
    return INIT_STATE
  }

  switch (action.type) {

    //To Fetch DB Data
    case FETCH_DB_DATA:
      return { ...state, loading: true, FetchDBData: [] };

    //To Fetch DB Data success
    case FETCH_DB_DATA_SUCCESS:
      return { ...state, loading: false, FetchDBData: action.payload };

    //To Fetch DB Data failure
    case FETCH_DB_DATA_FAILURE:
      return { ...state, loading: false, FetchDBData: [] }

    default:
      return { ...state };
  }
};
