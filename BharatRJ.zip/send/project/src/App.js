/**
* Main App
*/
import React from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

// css
import './asset';

// app component
import AppWidget from './container/App';
import { configureStore } from './store';

const App = () => (
  <Provider store={configureStore()}>
    <Router>
      <Switch>
        <Route path="/" component={AppWidget} />
      </Switch>
    </Router>
  </Provider>
);

export default App;