/**
 * Bharat Jograna - A Demo Project For Up Force Tech
 * Created By BharatRJ
 */
import React from 'react';
import ReactDOM from 'react-dom';

// Save a reference to the root element for reuse
const rootEl = document.getElementById("root");
const MainApp = require('./App').default;

ReactDOM.render(<MainApp />, rootEl);