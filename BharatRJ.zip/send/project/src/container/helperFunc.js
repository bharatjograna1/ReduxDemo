import axios from 'axios';

/**
 * Send Todos Request To Server
 */
export const getJSONServerAPI = async () => {

    var responseData = await axios.get("http://localhost:3000/shipments")
        .then(response => JSON.parse(JSON.stringify(response)))
        .catch(error => JSON.parse(JSON.stringify(error.response)));

    return responseData;
}
