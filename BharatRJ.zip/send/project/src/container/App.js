import React, { Component } from 'react';
import ComponentWdgt from '../component';

class App extends Component {
    render() {
        return (
            <div>
                <ComponentWdgt />
            </div>
        );
    }
}

export default App;