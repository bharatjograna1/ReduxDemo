/**
 * Active User Component
 */
import React from 'react';
import { Badge } from 'reactstrap';
import { connect } from "react-redux";
import MUIDataTable from "mui-datatables";
import { fetchDBData } from '../actions'
import CustomFooter from './CustomFooter';

//Columns Object
const columns = [
    {
        name: "#",
        options: { filter: false, sort: false }
    },
    {
        name: "ID",
        options: { filter: false, sort: true }
    },
    {
        name: "User Id",
        options: { filter: true, sort: true }
    },
    {
        name: "Name",
        options: { filter: true, sort: true }
    },
    {
        name: "Mode",
        options: { filter: true, sort: true }
    },
    {
        name: "Type",
        options: { filter: true, sort: true }
    },
    {
        name: "Destination",
        options: { filter: true, sort: true }
    },
    {
        name: "Origin",
        options: { filter: true, sort: true }
    },
    {
        name: "Total",
        options: { filter: true, sort: true }
    },
    {
        name: "Status",
        options: { filter: false, sort: true }
    },
];

class index extends React.Component {
    constructor(props, context) {
        super(props);
        this.state = {
            data: {
                PageNo: 0,
                PageSize: 10,
                totalCount: 0
            },
            ReportData: [],
        }
    }

    componentWillMount() {
        this.fetchDBReport(this.state.data.PageNo, this.state.data.PageSize)
    }

    //function to handle server side pagination
    fetchDBReport = (PageNo, PageSize) => {
        var newObj = Object.assign({}, this.state.data);
        newObj['PageNo'] = PageNo > 0 ? PageNo : this.state.data.PageNo;
        newObj['PageSize'] = PageSize > 0 ? PageSize : this.state.data.PageSize;
        this.setState({ data: newObj });

        //For Action API...
        var reqObj = newObj;
        reqObj.PageNo = PageNo > 0 ? PageNo - 1 : 0;
        this.props.fetchDBData(reqObj);
    }


    handlePageChange = (pageNumber) => {
        this.fetchDBReport(pageNumber);
    }

    onChangeRowsPerPage = (event) => {
        this.fetchDBReport(1, event.target.value);
    };

    componentWillReceiveProps(nextProps) {
        if (nextProps.FetchDBData) {
            this.setState({ ReportData: nextProps.FetchDBData })
        }
    }

    render() {
        const { PageNo, PageSize, totalCount } = this.state.data;
        const { ReportData } = this.state;

        const options = {
            search: true,
            filterType: "select",
            responsive: "scroll",
            selectableRows: false,
            resizableColumns: false,
            viewColumns: false,
            filter: true,
            sort: true,
            print: false,
            download: false,
            serverSide: ReportData.length !== 0 ? true : false,
            page: PageNo,
            count: totalCount,
            rowsPerPage: PageSize,
            textLabels: {
                body: {
                    noMatch: "Empty Table",
                    toolTip: "sort",
                }
            },
            customFooter: (count, page, rowsPerPage) => {
                var page1 = page > 0 ? page + 1 : 1;
                return (
                    <CustomFooter count={count} page={page1} rowsPerPage={rowsPerPage} handlePageChange={this.handlePageChange} onChangeRowsPerPage={this.onChangeRowsPerPage} />
                );
            },
            onTableChange: (action, tableState) => {
                if (action === 'changeRowsPerPage' || action === 'changePage') {
                    this.fetchDBReport(tableState.page, tableState.rowsPerPage);
                }
            }
        };

        return (
            <div className="Table">
                <MUIDataTable
                    title="Shipping Data Report"
                    columns={columns}
                    options={options}
                    data={ReportData.map((lst, key) => {
                        return [
                            (key + 1) + (PageNo * PageSize),
                            lst.id,
                            lst.userId,
                            lst.name,
                            lst.mode,
                            lst.type,
                            lst.destination,
                            lst.origin,
                            lst.total,
                            <Badge
                                className="w-100"
                                color={
                                    lst.status === "NEW" ? "info"
                                        : lst.status === "ACTIVE" ? "primary"
                                            : lst.status === "COMPLETED" ? "success"
                                                : "secondary"}
                            >
                                {lst.status}
                            </Badge>
                        ]
                    })}
                />
            </div>
        )
    }
}

//Map state to props...
const mapStateToProps = ({ FetchDBDataRdcr }) => {
    const { loading, FetchDBData } = FetchDBDataRdcr;
    return { loading, FetchDBData };
}

export default connect(mapStateToProps, {
    fetchDBData,
})(index);
