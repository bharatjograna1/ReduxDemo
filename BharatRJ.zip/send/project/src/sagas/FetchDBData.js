/**
 * Feedback Sagas
 */
import { all, call, fork, put, takeEvery } from 'redux-saga/effects';

import {
    FETCH_DB_DATA,
} from '../actions';

import {
    fetchDBDataSuccess,
    fetchDBDataFailure,
} from '../actions';

import { getJSONServerAPI } from '../container/helperFunc';

//Function for Fetch DB Data From Server
function* fetchDBDataAPI() {
    const response = yield call(getJSONServerAPI);

    try {
        if (response.status === 200) {
            yield put(fetchDBDataSuccess(response.data));
        } else {
            yield put(fetchDBDataFailure(response.data));
        }
    } catch (error) {
        yield put(fetchDBDataFailure(error));
    }
}

/* Create Sagas method for Fetch DB Data */
export function* fetchDBDataSaga() {
    yield takeEvery(FETCH_DB_DATA, fetchDBDataAPI);
}

/* Export methods to Fetch DB Data rootSagas */
export default function* rootSaga() {
    yield all([
        fork(fetchDBDataSaga)
    ]);
}