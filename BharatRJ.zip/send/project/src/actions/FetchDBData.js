/**
 * Redux App Settings Actions
 */

//For Fetch DB Data
export const FETCH_DB_DATA = "FETCH_DB_DATA";
export const FETCH_DB_DATA_SUCCESS = "FETCH_DB_DATA_SUCCESS";
export const FETCH_DB_DATA_FAILURE = "FETCH_DB_DATA_FAILURE";

/**
 * Redux Action To Fetch DB Data
 */
export const fetchDBData = (request) => ({
    type: FETCH_DB_DATA,
    payload: request
});

/**
 * Redux Action To Fetch DB Data Success
 */
export const fetchDBDataSuccess = (response) => ({
    type: FETCH_DB_DATA_SUCCESS,
    payload: response
});

/**
 * Redux Action To Fetch DB Data Failure
 */
export const fetchDBDataFailure = (error) => ({
    type: FETCH_DB_DATA_FAILURE,
    payload: error
});